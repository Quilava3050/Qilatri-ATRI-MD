import similarity from 'similarity'

const threshold = 0.72

export async function before(m) {
    let id = m.chat

    // ✅ Cek apakah chat sedang aktif soal teka-teki
    if (!this.tekateki || !(id in this.tekateki)) return true
    if (!m.quoted || !m.text) return true

    // ✅ Hanya lanjut jika membalas pesan soal aktif
    const idSoal = this.tekateki[id][0]?.id
    if (m.quoted.id !== idSoal) return true

    let json = this.tekateki[id][1]
    let jawabanBenar = json.jawaban.toLowerCase().trim()
    let userJawab = m.text.toLowerCase().trim()

    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(userJawab)
    if (isSurrender) {
        clearTimeout(this.tekateki[id][3])
        delete this.tekateki[id]
        return m.reply('*Yah, Menyerah ya... 😢*')
    }

    if (userJawab === jawabanBenar) {
        global.db.data.users[m.sender].exp += 500
        global.db.data.users[m.sender].limit += 1
        global.db.data.users[m.sender].koin += 200
        clearTimeout(this.tekateki[id][3])
        delete this.tekateki[id]
        return m.reply(`*✓ Benar!* 🎉\nKamu mendapatkan:\n• 500 Exp\n• 200 Koin\n• 1 Limit`)
    }

    if (similarity(userJawab, jawabanBenar) >= threshold) {
        return m.reply('*Dikit lagi!* 😬')
    }

    return m.reply('*Salah!* ❌')
}

export const exp = 0